import pygame
from main_copy import clock
from controller import pause
from pygame.locals import *



                
       
   
    
    